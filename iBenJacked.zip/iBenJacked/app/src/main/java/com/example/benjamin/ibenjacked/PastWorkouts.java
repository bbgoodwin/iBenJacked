package com.example.benjamin.ibenjacked;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.BounceInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;

import java.util.ArrayList;


public class PastWorkouts extends AppCompatActivity {

    private DatabaseManager db;
    private ArrayList<Workout> workoutList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = new DatabaseManager(this);

        LinearLayout linearlayout = new LinearLayout(this);

        linearlayout.setOrientation(LinearLayout.VERTICAL);

        LayoutParams linearlayoutlayoutparams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);

        setContentView(linearlayout, linearlayoutlayoutparams);

        LayoutParams LayoutTitle = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        LayoutTitle.gravity=Gravity.CENTER;

        LayoutParams LayoutWorkouts = new LayoutParams(LayoutParams.MATCH_PARENT, 588);
        LayoutWorkouts.topMargin=25;

        LayoutParams ButtonLayout = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);

        TextView title = new TextView(this);
        Button back = new Button(this);
        com.baoyz.swipemenulistview.SwipeMenuListView workoutDisplay = new com.baoyz.swipemenulistview.SwipeMenuListView(this);

        title.setText("Past Workouts");
        back.setText("Back");
        back.setBackgroundColor(Color.parseColor("#e68a00"));

        title.setTextSize(25);

        title.setLayoutParams(LayoutTitle);
        back.setLayoutParams(ButtonLayout);
        workoutDisplay.setLayoutParams(LayoutWorkouts);


        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                change(v);
            }
        });

        linearlayout.addView(title);

        final SwipeMenuListView listView = (SwipeMenuListView) workoutDisplay;

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, db.selectWorkouts());
        listView.setAdapter(adapter);
        // Close Interpolator
        listView.setCloseInterpolator(new BounceInterpolator());
        // Open Interpolator
        listView.setOpenInterpolator(new BounceInterpolator());

        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {

                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9,
                        0x3F, 0x25)));
                // set item width
                deleteItem.setWidth(170);
                // set a icon
                deleteItem.setIcon(R.drawable.ic_get_rid_of);
                // add to menu
                menu.addMenuItem(deleteItem);
            }
        };

        listView.setMenuCreator(creator);

        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        db.removeWorkout(workoutList.get(position).getId());
                        finish();
                        startActivity(getIntent());
                        break;
                }
                // false : close the menu; true : not close the menu
                return false;
            }
        });

        linearlayout.addView(listView);

        linearlayout.addView(back);

    }

    public void change(View v) {
        Intent myIntent = new Intent(this, Profile.class);
        this.startActivity(myIntent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }
}

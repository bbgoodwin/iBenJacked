package com.example.benjamin.ibenjacked;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;


public class PastWorkouts extends AppCompatActivity {

    private DatabaseManager db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = new DatabaseManager(this);

        LinearLayout linearlayout = new LinearLayout(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
                LayoutParams.FILL_PARENT));
        scroll.addView(linearlayout);

        linearlayout.setOrientation(LinearLayout.VERTICAL);

        LayoutParams linearlayoutlayoutparams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);

        setContentView(linearlayout, linearlayoutlayoutparams);

        LayoutParams LayoutTitle = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

        LayoutParams LayoutWorkouts = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

        LayoutParams ButtonLayout = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);

        TextView title = new TextView(this);
        TextView workouts = new TextView(this);
        Button back = new Button(this);

        title.setText("Past Workouts");
        workouts.setText(db.selectWorkouts());
        back.setText("Back");

        title.setTextSize(25);
        workouts.setTextSize(15);

        title.setLayoutParams(LayoutTitle);
        workouts.setLayoutParams(LayoutWorkouts);
        back.setLayoutParams(ButtonLayout);

        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                change(v);
            }
        });

        linearlayout.addView(title);
        linearlayout.addView(workouts);
        linearlayout.addView(back);


    }

    public void change(View v) {
        Intent myIntent = new Intent(this, Profile.class);
        this.startActivity(myIntent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }
}

package com.example.benjamin.ibenjacked;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;

import java.util.ArrayList;

public class Profile extends AppCompatActivity {

    private DatabaseManager db;
    private ArrayList<Workout> workoutList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new DatabaseManager(this);
        workoutList = db.displayTodayWorkouts();
        setContentView(R.layout.activity_profile);
        setGreet();

        View v = this.getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }

        final SwipeMenuListView listView = (SwipeMenuListView) findViewById(R.id.listView);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, db.displayTodayWorkouts());
        listView.setAdapter(adapter);
        // Close Interpolator
        listView.setCloseInterpolator(new BounceInterpolator());
        // Open Interpolator
        listView.setOpenInterpolator(new BounceInterpolator());

        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {

                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9,
                        0x3F, 0x25)));
                // set item width
                deleteItem.setWidth(170);
                // set a icon
                deleteItem.setIcon(R.drawable.ic_get_rid_of);
                // add to menu
                menu.addMenuItem(deleteItem);
            }
        };

        listView.setMenuCreator(creator);

        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        db.removeWorkout(workoutList.get(position).getId());
                        finish();
                        startActivity(getIntent());
                        break;
                }
                // false : close the menu; true : not close the menu
                return false;
            }
        });

    }

    public void setGreet() {
        TextView greet = (TextView) findViewById(R.id.Greet);
        greet.setText("Hello " + SignIn.signedInUser + "!");
    }

    public void changeToWorkout(View v) {
        Intent myIntent = new Intent(this, addWorkout.class);
        this.startActivity(myIntent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    public void changeToPast(View v) {
        Intent myIntent = new Intent(this, PastWorkouts.class);
        this.startActivity(myIntent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

}

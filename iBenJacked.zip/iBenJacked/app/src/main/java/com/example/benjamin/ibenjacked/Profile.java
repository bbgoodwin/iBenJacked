package com.example.benjamin.ibenjacked;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Profile extends AppCompatActivity {

    private DatabaseManager db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new DatabaseManager(this);
        setContentView(R.layout.activity_profile);
        setGreet();
        TextView display = (TextView) findViewById(R.id.Workouts);
        if(db.displayTodayWorkouts().length()<10){
            display.setText("You have not done any workouts yet.");
        }
        else
            displayWorkouts();
    }

    public void setGreet() {
        TextView greet = (TextView) findViewById(R.id.Greet);
        greet.setText("Hello " + SignIn.signedInUser + "!");
    }

    public void removeWorkout(View view) {
        EditText idview = (EditText) findViewById(R.id.DeleteText);

        int id = Integer.valueOf(idview.getText().toString());

        try {
            db.removeWorkout(id);
            displayWorkouts();
            Toast.makeText(this, "Workout Removed", Toast.LENGTH_SHORT).show();

        } catch (Exception exception) {
            Toast.makeText(this, "Error: " + exception.getMessage(), Toast.LENGTH_LONG).show();
        }

        idview.setText("");
        TextView display = (TextView) findViewById( R.id.Workouts);
        if(db.displayTodayWorkouts().length()<10){
            display.setText("You have not done any workouts yet.");
        }
        else
            displayWorkouts();
        View v = this.getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    public void displayWorkouts() {
        TextView display = (TextView) findViewById(R.id.Workouts);
        try {
            display.setText(db.displayTodayWorkouts());
        } catch (Exception exception) {
            Toast.makeText(this, "Error: " + exception.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void changeToWorkout(View v) {
        Intent myIntent = new Intent(this, addWorkout.class);
        this.startActivity(myIntent);
        overridePendingTransition(R.anim.animation, 0);
    }

    public void changeToPast(View v){
        Intent myIntent = new Intent(this, PastWorkouts.class);
        this.startActivity(myIntent);
        overridePendingTransition(R.anim.animation, 0);
    }

}

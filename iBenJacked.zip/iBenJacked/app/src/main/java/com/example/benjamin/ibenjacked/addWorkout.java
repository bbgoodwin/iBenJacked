package com.example.benjamin.ibenjacked;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class addWorkout extends Activity implements
        AdapterView.OnItemSelectedListener {

    private Spinner spinner, workoutSpinner;
    private Profile pro = new Profile();
    private ImageView workout_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_workout);

        spinner = (Spinner) findViewById(R.id.body);
        workoutSpinner = (Spinner) findViewById(R.id.workouts);
        spinner.setOnItemSelectedListener(this);
        workoutSpinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

        String value = String.valueOf(spinner.getSelectedItem());
        Spinner spinner = (Spinner) arg0;

        if (spinner.getId() == R.id.body) {
            if (value.contentEquals("Arms")) {
                List<String> workouts = new ArrayList<String>();
                workouts.add("Choose a Workout");
                workouts.add("Close Grip Curl");
                workouts.add("Hammer Curl");
                workouts.add("Dips");
                workouts.add("Neutral Grip Triceps Extension");
                workouts.add("Suspension Trainer Biceps Curl");
                ArrayAdapter<String> workoutAdapter = new ArrayAdapter<String>(this,
                        android.R.layout.simple_spinner_item, workouts);
                workoutAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                workoutAdapter.notifyDataSetChanged();
                workoutSpinner.setAdapter(workoutAdapter);
            } else if (String.valueOf(spinner.getSelectedItem()).contentEquals("Legs")) {
                List<String> workouts = new ArrayList<String>();
                workouts.add("Choose a Workout");
                workouts.add("Squat");
                workouts.add("Dumbbell Stepup");
                workouts.add("Deadlift");
                workouts.add("Leg Press");
                workouts.add("Walking Lunge");
                ArrayAdapter<String> workoutAdapter2 = new ArrayAdapter<String>(this,
                        android.R.layout.simple_spinner_item, workouts);
                workoutAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                workoutAdapter2.notifyDataSetChanged();
                workoutSpinner.setAdapter(workoutAdapter2);
            } else if (String.valueOf(spinner.getSelectedItem()).contentEquals("Abs")) {
                List<String> workouts = new ArrayList<String>();
                workouts.add("Choose a Workout");
                workouts.add("Ab Wheel Rollout");
                workouts.add("Barbell Russian Twist");
                workouts.add("Flutter Kick");
                workouts.add("Medicine Ball Russian Twist");
                workouts.add("Plank");
                ArrayAdapter<String> workoutAdapter3 = new ArrayAdapter<String>(this,
                        android.R.layout.simple_spinner_item, workouts);
                workoutAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                workoutAdapter3.notifyDataSetChanged();
                workoutSpinner.setAdapter(workoutAdapter3);
            } else if (String.valueOf(spinner.getSelectedItem().toString()).contentEquals("Chest")) {
                List<String> workouts = new ArrayList<String>();
                workouts.add("Choose a Workout");
                workouts.add("Barbell Bench Press");
                workouts.add("Dumbbell Fly");
                workouts.add("Cable Crossover");
                workouts.add("Chest Press Machine");
                workouts.add("Pullover");
                ArrayAdapter<String> workoutAdapter4 = new ArrayAdapter<String>(this,
                        android.R.layout.simple_spinner_item, workouts);
                workoutAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                workoutAdapter4.notifyDataSetChanged();
                workoutSpinner.setAdapter(workoutAdapter4);
            } else if (String.valueOf(spinner.getSelectedItem().toString()).contentEquals("Back")) {
                List<String> workouts = new ArrayList<String>();
                workouts.add("Choose a Workout");
                workouts.add("Deadlift");
                workouts.add("Incline Dumbbell Row");
                workouts.add("Pullup");
                workouts.add("Landmine One Arm Row");
                workouts.add("Rotational Inverted Row");
                ArrayAdapter<String> workoutAdapter5 = new ArrayAdapter<String>(this,
                        android.R.layout.simple_spinner_item, workouts);
                workoutAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                workoutAdapter5.notifyDataSetChanged();
                workoutSpinner.setAdapter(workoutAdapter5);
            }
        } else if (spinner.getId() == R.id.workouts) {

            String workout;

            try {
                workout = workoutSpinner.getSelectedItem().toString();
            } catch (Exception e) {
                Toast.makeText(this, "Choose a Workout", Toast.LENGTH_SHORT).show();
                workout = "";
            }
            workout_img = findViewById(R.id.workoutPic);
            Animation startAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation);
            workout_img.startAnimation(startAnimation);
            switch (workout) {
                case "Close Grip Curl":
                    workout_img.setImageResource(R.drawable.closegripcurl);
                    break;
                case "Hammer Curl":
                    workout_img.setImageResource(R.drawable.hammercurl);
                    break;
                case "Dips":
                    workout_img.setImageResource(R.drawable.dips);
                    break;
                case "Ab Wheel Rollout":
                    workout_img.setImageResource(R.drawable.abwheelrollout);
                    break;
                case "Barbell Bench Press":
                    workout_img.setImageResource(R.drawable.barbellbenchpress);
                    break;
                case "Barbell Russian Twist":
                    workout_img.setImageResource(R.drawable.barbellrussiantwist);
                    break;
                case "Cable Crossover":
                    workout_img.setImageResource(R.drawable.cablecrossover);
                    break;
                case "Chest Press Machine":
                    workout_img.setImageResource(R.drawable.chestpressmachine);
                    break;
                case "Deadlift":
                    workout_img.setImageResource(R.drawable.deadlift);
                    break;
                case "Dumbbell Fly":
                    workout_img.setImageResource(R.drawable.dumbbellfly);
                    break;
                case "Dumbbell Stepup":
                    workout_img.setImageResource(R.drawable.dumbbellstepup);
                    break;
                case "Flutter Kick":
                    workout_img.setImageResource(R.drawable.flutterkick);
                    break;
                case "Incline Dumbbell Row":
                    workout_img.setImageResource(R.drawable.inclinedumbbellrow);
                    break;
                case "Landmine One Arm Row":
                    workout_img.setImageResource(R.drawable.landmineonearmrow);
                    break;
                case "Leg Press":
                    workout_img.setImageResource(R.drawable.legpress);
                    break;
                case "Medicine Ball Russian Twist":
                    workout_img.setImageResource(R.drawable.medicineballrussiantwist);
                    break;
                case "Neutral Grip Triceps Extension":
                    workout_img.setImageResource(R.drawable.neutralgriptricepsextension);
                    break;
                case "Plank":
                    workout_img.setImageResource(R.drawable.plank);
                    break;
                case "Pullover":
                    workout_img.setImageResource(R.drawable.pullover);
                    break;
                case "Pullup":
                    workout_img.setImageResource(R.drawable.pullup);
                    break;
                case "Rotational Inverted Row":
                    workout_img.setImageResource(R.drawable.rotationalinvertedrow);
                    break;
                case "Squat":
                    workout_img.setImageResource(R.drawable.squat);
                    break;
                case "Suspension Trainer Biceps Curl":
                    workout_img.setImageResource(R.drawable.suspensiontrainerbicepscurl);
                    break;
                case "Walking Lunge":
                    workout_img.setImageResource(R.drawable.walkinglunge);
                    break;
                default:
                    workout_img.setImageResource(0);
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        workout_img = findViewById(R.id.workoutPic);
        workout_img.setImageResource(0);
    }

    public void inputWorkout(View v) {
        DatabaseManager db = new DatabaseManager(this);
        EditText weight = (EditText) findViewById(R.id.weight);
        EditText sets = (EditText) findViewById(R.id.sets);
        EditText reps = (EditText) findViewById(R.id.reps);

        try {
            db.addWorkout(new Workout(0, "user", "date", workoutSpinner.getSelectedItem().toString(), spinner.getSelectedItem().toString(),
                    Integer.valueOf(weight.getText().toString()), Integer.valueOf(sets.getText().toString()), Integer.valueOf(reps.getText().toString())));
            Intent myIntent = new Intent(this, Profile.class);
            this.startActivity(myIntent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        }
        catch (Exception e){
            Toast.makeText(this, "Improper workout", Toast.LENGTH_LONG).show();
        }
    }

    public void change(View v) {
        Intent myIntent = new Intent(this, Profile.class);
        this.startActivity(myIntent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

}
